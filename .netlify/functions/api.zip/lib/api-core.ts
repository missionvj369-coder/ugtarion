var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var api_core_exports = {};
__export(api_core_exports, {
  buildRecord: () => buildRecord,
  createSupabaseAdmin: () => createSupabaseAdmin,
  handleGetCount: () => handleGetCount,
  handleGetProfile: () => handleGetProfile,
  handleLogin: () => handleLogin,
  handleRegister: () => handleRegister,
  loginSchema: () => loginSchema,
  registerSchema: () => registerSchema
});
module.exports = __toCommonJS(api_core_exports);
var import_supabase_js = require("@supabase/supabase-js");
var import_zod = require("zod");
const registerSchema = import_zod.z.object({
  name: import_zod.z.string().min(1, "Name is required"),
  dob: import_zod.z.string().min(4, "Date of birth is required"),
  email: import_zod.z.string().email("Invalid email address"),
  phone: import_zod.z.string().min(6, "Phone number is required"),
  pincode: import_zod.z.string().min(3, "Pincode is required"),
  city: import_zod.z.string().min(1, "City is required"),
  district: import_zod.z.string().min(1, "District is required"),
  state: import_zod.z.string().min(1, "State is required"),
  nation: import_zod.z.string().min(1, "Nation is required")
});
const loginSchema = import_zod.z.object({
  identifier: import_zod.z.string().min(1, "Universal ID or Email is required")
});
function createSupabaseAdmin() {
  const url = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !serviceKey) {
    throw new Error("Missing Supabase credentials: VITE_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY required");
  }
  return (0, import_supabase_js.createClient)(url, serviceKey, {
    auth: { persistSession: false }
  });
}
function buildRecord(profile, ranks) {
  return {
    id: profile.universal_id,
    name: profile.name,
    dob: profile.dob,
    email: profile.email,
    phone: profile.phone,
    pincode: profile.pincode,
    city: profile.city,
    district: profile.district,
    state: profile.state,
    nation: profile.nation,
    registeredAt: profile.created_at,
    order: Number(ranks.global_order),
    universeRank: Number(ranks.universe_rank),
    nationRank: Number(ranks.nation_rank),
    stateRank: Number(ranks.state_rank),
    districtRank: Number(ranks.district_rank),
    cityRank: Number(ranks.city_rank),
    pincodeRank: Number(ranks.pincode_rank)
  };
}
async function handleGetCount(supabase) {
  try {
    const { data, error } = await supabase.rpc("get_total_registrations");
    if (error) throw new Error(error.message);
    return { data: { count: Number(data) || 0 } };
  } catch (err) {
    return { error: err.message || "Failed to fetch count" };
  }
}
async function handleGetProfile(supabase, uid) {
  try {
    const { data, error } = await supabase.rpc("login_user_atomic", { p_identifier: uid });
    if (error) throw new Error(error.message);
    if (!data || data.length === 0) {
      return { error: "Profile not found." };
    }
    return { data: buildRecord(data[0], data[0]) };
  } catch (err) {
    return { error: err.message || "Failed to fetch profile" };
  }
}
async function handleRegister(supabase, body) {
  const parse = registerSchema.safeParse(body);
  if (!parse.success) {
    return { error: "Invalid registration payload", details: parse.error.errors };
  }
  const { name, dob, email, phone, pincode, city, district, state, nation } = parse.data;
  try {
    const { data, error } = await supabase.rpc("register_user_atomic", {
      p_name: name.trim(),
      p_dob: dob,
      p_email: email.trim().toLowerCase(),
      p_phone: phone.trim(),
      p_pincode: pincode.trim(),
      p_city: city.trim(),
      p_district: district.trim(),
      p_state: state.trim(),
      p_nation: nation.trim()
    });
    if (error) throw new Error(error.message);
    if (!data || data.length === 0) {
      return { error: "Registration failed - no data returned" };
    }
    return { data: buildRecord(data[0], data[0]) };
  } catch (err) {
    if (err.message?.includes("already associated")) {
      return { error: "This email is already associated with a Universal ID." };
    }
    return { error: err.message || "Registration failed" };
  }
}
async function handleLogin(supabase, body) {
  const parse = loginSchema.safeParse(body);
  if (!parse.success) {
    return { error: "Invalid login payload", details: parse.error.errors };
  }
  const { identifier } = parse.data;
  try {
    const { data, error } = await supabase.rpc("login_user_atomic", {
      p_identifier: identifier.trim().toLowerCase()
    });
    if (error) throw new Error(error.message);
    if (!data || data.length === 0) {
      return { error: "Universal ID or Email not found. Please check spelling or register first." };
    }
    return { data: buildRecord(data[0], data[0]) };
  } catch (err) {
    return { error: err.message || "Login failed" };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  buildRecord,
  createSupabaseAdmin,
  handleGetCount,
  handleGetProfile,
  handleLogin,
  handleRegister,
  loginSchema,
  registerSchema
});
