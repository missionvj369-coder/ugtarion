var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var api_exports = {};
__export(api_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(api_exports);
var import_supabase_js = require("@supabase/supabase-js");
var import_zod = require("zod");
var import_dotenv = __toESM(require("dotenv"), 1);
var import_api_core = require("../../lib/api-core.js");
import_dotenv.default.config({ path: ".env.server" });
const SUPABASE_URL = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  throw new Error("Missing SUPABASE_SERVICE_ROLE_KEY or VITE_SUPABASE_URL/SUPABASE_URL in function environment");
}
const supabase = (0, import_supabase_js.createClient)(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
  auth: { persistSession: false }
});
const defaultCorsHeaders = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": process.env.DEV_ORIGIN || "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
};
function jsonResponse(statusCode, payload) {
  return {
    statusCode,
    headers: defaultCorsHeaders,
    body: JSON.stringify(payload)
  };
}
async function handler(event) {
  try {
    if (event.httpMethod === "OPTIONS") {
      return { statusCode: 204, headers: defaultCorsHeaders };
    }
    const prefix = "/.netlify/functions/api";
    const path = event.path && event.path.startsWith(prefix) ? event.path.slice(prefix.length) : event.path || "/";
    const parts = path.split("/").filter(Boolean);
    if (event.httpMethod === "GET" && parts[0] === "count") {
      const result = await (0, import_api_core.handleGetCount)(supabase);
      return jsonResponse(result.error ? 500 : 200, result.error ? { error: result.error } : result.data);
    }
    if (event.httpMethod === "GET" && parts[0] === "profile" && parts[1]) {
      const result = await (0, import_api_core.handleGetProfile)(supabase, parts[1]);
      return jsonResponse(result.error ? result.error === "Profile not found." ? 404 : 500 : 200, result.error ? { error: result.error } : result.data);
    }
    if (event.httpMethod === "POST" && parts[0] === "register") {
      const body = event.body ? JSON.parse(event.body) : {};
      const result = await (0, import_api_core.handleRegister)(supabase, body);
      return jsonResponse(result.error ? result.error.includes("already associated") ? 409 : 500 : 200, result.error ? { error: result.error, details: result.details } : result.data);
    }
    if (event.httpMethod === "POST" && parts[0] === "login") {
      const body = event.body ? JSON.parse(event.body) : {};
      const result = await (0, import_api_core.handleLogin)(supabase, body);
      return jsonResponse(result.error ? result.error.includes("not found") ? 404 : 500 : 200, result.error ? { error: result.error, details: result.details } : result.data);
    }
    return jsonResponse(404, { error: "Not found" });
  } catch (err) {
    console.error("Function error:", err?.message || err);
    return jsonResponse(500, { error: err?.message || "Internal error" });
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
